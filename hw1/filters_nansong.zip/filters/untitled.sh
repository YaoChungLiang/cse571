#!/bin/bash

# python3 localization.py ekf --seed 0
python3 localization.py ekf 