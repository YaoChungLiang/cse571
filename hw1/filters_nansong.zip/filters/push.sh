#!/bin/bash

git add -A
git commit -m "Auto commit"
git push
